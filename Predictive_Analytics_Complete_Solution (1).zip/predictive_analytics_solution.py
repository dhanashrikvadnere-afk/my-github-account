import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 1. Load dataset
df = pd.read_csv("historical_sales_predictive_analytics.csv")

# 2. Clean and preprocess
df["Date"] = pd.to_datetime(df["Date"])
df = df.dropna().sort_values("Date")
df["Year"] = df["Date"].dt.year
df["Month"] = df["Date"].dt.month

print("First 5 rows:")
print(df.head())
print("\nDataset information:")
print(df.info())
print("\nMissing values:")
print(df.isnull().sum())

# 3. Historical trend visualization
plt.figure(figsize=(12, 5))
plt.plot(df["Date"], df["Sales"])
plt.xlabel("Date")
plt.ylabel("Sales")
plt.title("Historical Sales Trend")
plt.tight_layout()
plt.show()

# 4. Prepare features and target
X = df[["Year", "Month"]]
y = df["Sales"]

# 5. Split into training and testing data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

# 6. Train Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 7. Predict test data
y_pred = model.predict(X_test)

# 8. Evaluate model
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\nMODEL EVALUATION")
print("MAE :", round(mae, 2))
print("RMSE:", round(rmse, 2))
print("R2 Score:", round(r2, 4))

# 9. Actual vs Predicted visualization
plt.figure(figsize=(10, 5))
plt.plot(y_test.values, label="Actual Sales")
plt.plot(y_pred, label="Predicted Sales")
plt.xlabel("Test Record")
plt.ylabel("Sales")
plt.title("Actual vs Predicted Sales")
plt.legend()
plt.tight_layout()
plt.show()

# 10. Forecast next 12 months
last_date = df["Date"].max()
future_dates = pd.date_range(
    start=last_date + pd.offsets.MonthBegin(1), periods=12, freq="MS"
)

future = pd.DataFrame({
    "Date": future_dates,
    "Year": future_dates.year,
    "Month": future_dates.month
})

future["Predicted Sales"] = model.predict(future[["Year", "Month"]])
future["Predicted Sales"] = future["Predicted Sales"].round(2)

print("\nNEXT 12 MONTHS FORECAST")
print(future[["Date", "Predicted Sales"]].to_string(index=False))

# 11. Forecast visualization
plt.figure(figsize=(12, 5))
plt.plot(df["Date"], df["Sales"], label="Historical Sales")
plt.plot(future["Date"], future["Predicted Sales"], label="Future Prediction")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.title("Historical and Future Sales Forecast")
plt.legend()
plt.tight_layout()
plt.show()

# 12. Save prediction
future.to_csv("future_sales_predictions.csv", index=False)
print("\nFuture predictions saved as future_sales_predictions.csv")