# Predictive Analytics Using Historical Data

## Objective
Build a predictive model to forecast future sales trends using historical data.

## Dataset
`historical_sales_predictive_analytics.csv`
- 60 monthly records
- Date: January 2021 to December 2025
- Sales: historical monthly sales values

## Key Features Covered
1. Clean and preprocess historical data
2. Visualize historical sales trends
3. Use Linear Regression for prediction
4. Evaluate model accuracy using MAE, RMSE and R2 Score
5. Forecast the next 12 months
6. Visualize future predictions

## Files
- `historical_sales_predictive_analytics.csv` - original dataset
- `cleaned_sales_data.csv` - cleaned and feature-engineered dataset
- `future_sales_predictions.csv` - next 12 months forecast
- `model_metrics.csv` - evaluation metrics
- `predictive_analytics_solution.py` - complete Python solution
- `01_historical_sales_trend.png` - historical trend chart
- `02_actual_vs_predicted.png` - model evaluation chart
- `03_future_sales_forecast.png` - forecast chart
- `requirements.txt` - required Python libraries

## Model
Linear Regression is used with:
- Year
- Month

Target:
- Sales

## Evaluation
The generated `model_metrics.csv` contains the exact MAE, RMSE and R2 values from the run.

## How to Run in Google Colab
1. Open Google Colab.
2. Upload `historical_sales_predictive_analytics.csv`.
3. Upload/copy `predictive_analytics_solution.py`, or paste its code into notebook cells.
4. Install libraries if needed:
   `!pip install pandas numpy matplotlib scikit-learn`
5. Run the code from top to bottom.

## Conclusion
The project analyzes historical sales patterns and uses Linear Regression to estimate future sales. The model is evaluated using standard regression metrics and the results are visualized to support data-driven forecasting.