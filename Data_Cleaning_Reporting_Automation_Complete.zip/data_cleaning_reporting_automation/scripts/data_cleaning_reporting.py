
import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
INPUT = BASE / "data" / "raw_sales.csv"
OUTPUT = BASE / "output"
OUTPUT.mkdir(exist_ok=True)

def clean_data(df):
    df = df.copy()

    # Standardize text fields
    for col in ["Customer", "Product", "Category", "Payment"]:
        df[col] = df[col].astype("string").str.strip()

    df["Category"] = df["Category"].str.title()
    df["Payment"] = df["Payment"].str.upper()

    # Parse dates
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce", dayfirst=False)

    # Numeric conversion
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
    df["Unit_Price"] = pd.to_numeric(df["Unit_Price"], errors="coerce")

    # Remove exact duplicate rows
    df = df.drop_duplicates()

    # Remove duplicate Order_ID records, keeping the first occurrence
    df = df.drop_duplicates(subset=["Order_ID"], keep="first")

    # Fill missing numeric values with sensible medians
    df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median())
    df["Unit_Price"] = df["Unit_Price"].fillna(df["Unit_Price"].median())

    # Fill missing dates using the median valid date
    if df["Date"].isna().any():
        median_date = df["Date"].dropna().sort_values().iloc[len(df["Date"].dropna()) // 2]
        df["Date"] = df["Date"].fillna(median_date)

    # Create calculated field
    df["Sales"] = df["Quantity"] * df["Unit_Price"]

    return df.sort_values("Date").reset_index(drop=True)

def create_report(df):
    summary = {
        "Total Orders": len(df),
        "Total Quantity": int(df["Quantity"].sum()),
        "Total Sales": float(df["Sales"].sum()),
        "Average Order Value": float(df["Sales"].mean()),
        "Top Product": df.groupby("Product")["Sales"].sum().idxmax(),
        "Top Category": df.groupby("Category")["Sales"].sum().idxmax(),
    }

    product = df.groupby("Product", as_index=False)["Sales"].sum().sort_values("Sales", ascending=False)
    category = df.groupby("Category", as_index=False)["Sales"].sum().sort_values("Sales", ascending=False)
    payment = df.groupby("Payment", as_index=False)["Sales"].sum().sort_values("Sales", ascending=False)

    pd.DataFrame([summary]).to_csv(OUTPUT/"summary.csv", index=False)
    product.to_csv(OUTPUT/"product_summary.csv", index=False)
    category.to_csv(OUTPUT/"category_summary.csv", index=False)
    payment.to_csv(OUTPUT/"payment_summary.csv", index=False)
    df.to_csv(OUTPUT/"cleaned_sales.csv", index=False)

    return summary, product, category, payment

if __name__ == "__main__":
    data = pd.read_csv(INPUT)
    cleaned = clean_data(data)
    create_report(cleaned)
    print("Cleaning and reporting completed successfully.")
