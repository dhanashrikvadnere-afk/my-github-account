# Data Cleaning & Reporting Automation

## Objective
Automate a complete data-cleaning and reporting workflow using Python and Excel.

## Key Features
- Handles missing values
- Removes duplicate records
- Standardizes inconsistent category/payment values
- Converts dates and numeric fields
- Calculates Sales automatically
- Generates summary reports
- Creates an Excel report with charts
- Produces an HTML visual summary

## Project Structure
- `data/raw_sales.csv` - intentionally messy source data
- `scripts/data_cleaning_reporting.py` - reusable cleaning/reporting script
- `output/cleaned_sales.csv` - cleaned dataset
- `output/summary.csv` - KPI summary
- `output/product_summary.csv` - product-wise sales
- `output/category_summary.csv` - category-wise sales
- `output/payment_summary.csv` - payment-wise sales
- `output/automated_report.xlsx` - Excel report and charts
- `output/report.html` - browser-friendly visual report

## How to Run
1. Install Python 3.x.
2. Install dependencies:
   `pip install pandas openpyxl numpy`
3. Run:
   `python scripts/data_cleaning_reporting.py`
4. Open the files in the `output` folder.

## Expected Outcome
The project demonstrates data preprocessing, automation, reporting efficiency, and visual summaries.